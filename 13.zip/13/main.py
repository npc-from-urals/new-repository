import sys
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QDate
from PyQt5.QtGui import QPixmap
from database import Database
from login import LoginDialog

class MainWindow(QMainWindow):
    def __init__(self, user_role, username):
        super().__init__()
        self.db = Database()
        self.user_role = user_role
        self.username = username
        self.current_table = 'UvilirIzdel'
        self.selected_id = None
        self.init_ui()
        self.load_data()
    
    def init_ui(self):
        self.setWindowTitle(f'Ювелирный магазин | {self.username} ({self.user_role})')
        self.setGeometry(100, 100, 1100, 600)
        
        w = QWidget()
        self.setCentralWidget(w)
        l = QHBoxLayout(w)
        
        # Левая часть
        left = QWidget()
        left_l = QVBoxLayout(left)
        left_l.addWidget(QLabel(f' {self.username} | Роль: {self.user_role}'))
        
        g = QGroupBox('Таблица')
        g_l = QHBoxLayout()
        self.cb = QComboBox()
        self.cb.addItems(['Ювелирные изделия', 'Клиенты', 'Заказы'])
        self.cb.currentTextChanged.connect(self.on_table_change)
        g_l.addWidget(QLabel('Выбор:'))
        g_l.addWidget(self.cb)
        g.setLayout(g_l)
        left_l.addWidget(g)
        
        self.table = QTableWidget()
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.cellClicked.connect(lambda r,c: self.show_card(int(self.table.item(r,0).text())) if self.current_table=='UvilirIzdel' else None)
        left_l.addWidget(self.table)
        
        # Кнопки
        b_l = QHBoxLayout()
        self.btn_add = QPushButton('Добавить')
        self.btn_edit = QPushButton('Изменить')
        self.btn_delete = QPushButton('Удалить')
        if self.user_role == 'guest':
            for b in [self.btn_add, self.btn_edit, self.btn_delete]:
                b.setEnabled(False)
        self.btn_add.clicked.connect(self.add_record)
        self.btn_edit.clicked.connect(self.edit_record)
        self.btn_delete.clicked.connect(self.delete_record)
        b_l.addWidget(self.btn_add)
        b_l.addWidget(self.btn_edit)
        b_l.addWidget(self.btn_delete)
        
        btn_exit = QPushButton('Выход')
        btn_exit.clicked.connect(self.close)
        b_l.addWidget(btn_exit)
        left_l.addLayout(b_l)
        
        # Правая часть с карточкой товара
        right = QWidget()
        right_l = QVBoxLayout(right)
        self.card = QGroupBox('Карточка изделия')
        card_l = QVBoxLayout()
        
        self.img = QLabel()
        self.img.setAlignment(Qt.AlignCenter)
        self.img.setMinimumSize(250, 150)
        self.img.setStyleSheet('background-color: #f0f0f0; border: 1px solid #ccc;')
        
        # Загружаем заглушку
        self.show_default_image()
        
        self.info = QLabel('Выберите изделие')
        self.info.setAlignment(Qt.AlignCenter)
        self.info.setStyleSheet('font-size: 12px; padding: 5px;')
        
        card_l.addWidget(self.img)
        card_l.addWidget(self.info)
        self.card.setLayout(card_l)
        right_l.addWidget(self.card)
        
        l.addWidget(left, 2)
        l.addWidget(right, 1)
    
    def on_table_change(self, name):
        table_map = {'Ювелирные изделия':'UvilirIzdel', 'Клиенты':'Klienti', 'Заказы':'Zakazi'}
        self.current_table = table_map.get(name, 'UvilirIzdel')
        self.load_data()
        self.card.setVisible(self.current_table=='UvilirIzdel')
    
    def load_data(self):
        try:
            if self.current_table == 'UvilirIzdel':
                data = self.db.get_all_jewelry()
                headers = ['ID','Название','Страна','Завод','Материал','Проба','Вес','Камни','Цена']
            elif self.current_table == 'Klienti':
                data = self.db.get_all_klienti()
                headers = ['ID','Фамилия','Имя','Отчество','Адрес','Город']
            else:
                data = self.db.get_all_zakazi()
                headers = ['ID','Клиент','Изделие','Дата','Кол-во','Скидка','Цена']
            
            self.table.clear()
            self.table.setColumnCount(len(headers))
            self.table.setHorizontalHeaderLabels(headers)
            self.table.setRowCount(len(data))
            
            for i, row in enumerate(data):
                if self.current_table != 'Zakazi':
                    for j, val in enumerate(row):
                        self.table.setItem(i, j, QTableWidgetItem(str(val)))
                else:
                    vals = [row[0], row[6], row[7], row[3], row[4], f"{row[5]}%", f"{row[8]} руб."]
                    for j, val in enumerate(vals):
                        self.table.setItem(i, j, QTableWidgetItem(str(val)))
            self.table.resizeColumnsToContents()
        except Exception as e:
            print(f"Ошибка загрузки данных: {e}")
            QMessageBox.critical(self, 'Ошибка', f'Не удалось загрузить данные: {str(e)}')
    
    def show_card(self, id):
        try:
            i = self.db.get_jewelry_by_id(id)
            if i:
                self.info.setText(f"<b>{i[1]}</b><br>{i[2]} | {i[3]}<br>{i[4]} {i[5]}<br>Вес: {i[6]}г<br>Камни: {i[7]}<br>Цена: {i[8]} руб.")
                
                # Проверяем, является ли изделие цепочкой серебряной (ID=4)
                if id == 4 or 'Цепочка серебряная' in i[1]:
                    foto_path = 'chain.png'
                else:
                    foto_path = 'image.png'
                
                # Загружаем фото
                if os.path.exists(foto_path):
                    pixmap = QPixmap(foto_path)
                    if not pixmap.isNull():
                        scaled = pixmap.scaled(430, 330, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                        self.img.setPixmap(scaled)
                    else:
                        self.show_default_image()
                else:
                    self.show_default_image()
        except Exception as e:
            print(f"Ошибка: {e}")
            self.show_default_image()

    def show_default_image(self):
        """Показать изображение-заглушку"""
        try:
            if os.path.exists('image.png'):
                pixmap = QPixmap('image.png')
                if not pixmap.isNull():
                    scaled = pixmap.scaled(430, 330, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    self.img.setPixmap(scaled)
                else:
                    self.img.setText('Нет фото')
            else:
                self.img.setText('Нет фото')
        except:
            self.img.setText('Ошибка')
    
    def check_admin(self):
        if self.user_role == 'guest':
            QMessageBox.warning(self, 'Ошибка', 'Доступ запрещён')
            return False
        return True
    
    def add_record(self):
        if not self.check_admin(): return
        try:
            if self.current_table == 'UvilirIzdel':
                d = JewelryDialog(self, self.db)
            elif self.current_table == 'Klienti':
                d = KlientDialog(self, self.db)
            else:
                d = ZakazDialog(self, self.db)
            if d.exec_() == QDialog.Accepted:
                if self.current_table == 'UvilirIzdel':
                    self.db.add_jewelry(*d.get_data())
                elif self.current_table == 'Klienti':
                    self.db.add_klient(*d.get_data())
                else:
                    self.db.add_zakaz(*d.get_data())
                self.load_data()
                QMessageBox.information(self, 'Успех', 'Запись добавлена!')
        except Exception as e:
            QMessageBox.critical(self, 'Ошибка', f'Не удалось добавить запись: {str(e)}')
    
    def edit_record(self):
        if not self.check_admin(): return
        r = self.table.currentRow()
        if r < 0: 
            QMessageBox.warning(self, 'Ошибка', 'Выберите запись')
            return
        try:
            id = int(self.table.item(r,0).text())
            
            if self.current_table == 'UvilirIzdel':
                d = JewelryDialog(self, self.db, self.db.get_jewelry_by_id(id))
                if d.exec_() == QDialog.Accepted:
                    self.db.update_jewelry(id, *d.get_data())
            elif self.current_table == 'Klienti':
                for k in self.db.get_all_klienti():
                    if k[0] == id:
                        d = KlientDialog(self, self.db, k)
                        if d.exec_() == QDialog.Accepted:
                            self.db.update_klient(id, *d.get_data())
                        break
            else:
                for z in self.db.get_all_zakazi():
                    if z[0] == id:
                        d = ZakazDialog(self, self.db, z)
                        if d.exec_() == QDialog.Accepted:
                            self.db.update_zakaz(id, *d.get_data())
                        break
            self.load_data()
            QMessageBox.information(self, 'Успех', 'Запись обновлена!')
        except Exception as e:
            QMessageBox.critical(self, 'Ошибка', f'Не удалось изменить запись: {str(e)}')
    
    def delete_record(self):
        if not self.check_admin(): return
        r = self.table.currentRow()
        if r < 0: 
            QMessageBox.warning(self, 'Ошибка', 'Выберите запись')
            return
        try:
            id = int(self.table.item(r,0).text())
            if QMessageBox.question(self, 'Подтверждение', f'Удалить запись с ID {id}?', QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
                if self.current_table == 'UvilirIzdel':
                    self.db.delete_jewelry(id)
                elif self.current_table == 'Klienti':
                    self.db.delete_klient(id)
                else:
                    self.db.delete_zakaz(id)
                self.load_data()
                self.info.setText('Выберите изделие')
                self.show_default_image()
                QMessageBox.information(self, 'Успех', 'Запись удалена!')
        except Exception as e:
            QMessageBox.critical(self, 'Ошибка', f'Не удалось удалить запись: {str(e)}')


# ==================== Диалоговые окна ====================
class JewelryDialog(QDialog):
    def __init__(self, parent, db, data=None):
        super().__init__(parent)
        self.setWindowTitle('Изменить изделие' if data else 'Добавить изделие')
        self.setGeometry(100, 100, 400, 400)
        
        layout = QFormLayout(self)
        
        self.name_edit = QLineEdit()
        self.strana_edit = QLineEdit()
        self.zavod_edit = QLineEdit()
        
        self.material_combo = QComboBox()
        self.material_combo.addItems(['золото', 'серебро', 'платина'])
        
        self.proba_spin = QSpinBox()
        self.proba_spin.setRange(0, 1000)
        self.proba_spin.setSingleStep(5)
        
        self.ves_spin = QSpinBox()
        self.ves_spin.setRange(1, 1000)
        self.ves_spin.setSuffix(' г')
        
        self.kamni_combo = QComboBox()
        self.kamni_combo.addItems(['Нет', 'Да'])
        
        self.cena_spin = QSpinBox()
        self.cena_spin.setRange(0, 1000000)
        self.cena_spin.setSingleStep(1000)
        self.cena_spin.setSuffix(' руб')
        
        if data:
            self.name_edit.setText(data[1])
            self.strana_edit.setText(data[2])
            self.zavod_edit.setText(data[3])
            self.material_combo.setCurrentText(data[4])
            self.proba_spin.setValue(data[5])
            self.ves_spin.setValue(data[6])
            self.kamni_combo.setCurrentText(data[7])
            self.cena_spin.setValue(data[8])
        
        layout.addRow('Название:', self.name_edit)
        layout.addRow('Страна:', self.strana_edit)
        layout.addRow('Завод:', self.zavod_edit)
        layout.addRow('Материал:', self.material_combo)
        layout.addRow('Проба:', self.proba_spin)
        layout.addRow('Вес:', self.ves_spin)
        layout.addRow('Камни:', self.kamni_combo)
        layout.addRow('Цена:', self.cena_spin)
        
        # Кнопки
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addRow(button_box)  # Добавляем кнопки как отдельный ряд
    
    def get_data(self):
        return (self.name_edit.text(), self.strana_edit.text(),
                self.zavod_edit.text(), self.material_combo.currentText(),
                self.proba_spin.value(), self.ves_spin.value(),
                self.kamni_combo.currentText(), self.cena_spin.value())


class KlientDialog(QDialog):
    def __init__(self, parent, db, data=None):
        super().__init__(parent)
        self.setWindowTitle('Изменить клиента' if data else 'Добавить клиента')
        self.setGeometry(100, 100, 400, 300)
        
        layout = QFormLayout(self)
        
        self.familiy_edit = QLineEdit()
        self.imy_edit = QLineEdit()
        self.oychestvo_edit = QLineEdit()
        self.adres_edit = QLineEdit()
        self.gorod_edit = QLineEdit()
        
        if data:
            self.familiy_edit.setText(data[1])
            self.imy_edit.setText(data[2])
            self.oychestvo_edit.setText(data[3])
            self.adres_edit.setText(data[4])
            self.gorod_edit.setText(data[5])
        
        layout.addRow('Фамилия:', self.familiy_edit)
        layout.addRow('Имя:', self.imy_edit)
        layout.addRow('Отчество:', self.oychestvo_edit)
        layout.addRow('Адрес:', self.adres_edit)
        layout.addRow('Город:', self.gorod_edit)
        
        # Кнопки
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addRow(button_box)
    
    def get_data(self):
        return (self.familiy_edit.text(), self.imy_edit.text(),
                self.oychestvo_edit.text(), self.adres_edit.text(),
                self.gorod_edit.text())


class ZakazDialog(QDialog):
    def __init__(self, parent, db, data=None):
        super().__init__(parent)
        self.setWindowTitle('Изменить заказ' if data else 'Добавить заказ')
        self.db = db
        self.setGeometry(100, 100, 400, 300)
        
        layout = QFormLayout(self)
        
        # Клиент
        self.klient_combo = QComboBox()
        klienti = db.get_all_klienti()
        for k in klienti:
            fio = f"{k[1]} {k[2]} {k[3]}"
            self.klient_combo.addItem(f"{k[0]} - {fio}", k[0])
        
        # Изделие
        self.izdelie_combo = QComboBox()
        izdeliya = db.get_all_jewelry()
        for i in izdeliya:
            self.izdelie_combo.addItem(f"{i[0]} - {i[1]} ({i[8]} руб.)", i[0])
        
        self.kolichestvo_spin = QSpinBox()
        self.kolichestvo_spin.setRange(1, 100)
        
        self.skidka_spin = QSpinBox()
        self.skidka_spin.setRange(0, 100)
        self.skidka_spin.setSuffix(' %')
        
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate())
        
        if data:
            # data: [idZakazi, klient_id, izdelie_id, data, kol, skidka, fio, name, cena]
            self.klient_combo.setCurrentIndex(self.klient_combo.findData(data[1]))
            self.izdelie_combo.setCurrentIndex(self.izdelie_combo.findData(data[2]))
            self.kolichestvo_spin.setValue(data[4])
            self.skidka_spin.setValue(data[5])
            self.date_edit.setDate(QDate.fromString(data[3], 'yyyy-MM-dd'))
        
        layout.addRow('Клиент:', self.klient_combo)
        layout.addRow('Изделие:', self.izdelie_combo)
        layout.addRow('Количество:', self.kolichestvo_spin)
        layout.addRow('Скидка:', self.skidka_spin)
        layout.addRow('Дата:', self.date_edit)
        
        # Кнопки
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addRow(button_box)
    
    def get_data(self):
        return (self.klient_combo.currentData(), 
                self.izdelie_combo.currentData(),
                self.date_edit.date().toString('yyyy-MM-dd'),
                self.kolichestvo_spin.value(),
                self.skidka_spin.value())


# ==================== Запуск ====================
if __name__ == '__main__':
    app = QApplication(sys.argv)
    
    login_dialog = LoginDialog()
    if login_dialog.exec_() == QDialog.Accepted:
        user_role = login_dialog.get_role()
        username = login_dialog.get_username()
        
        window = MainWindow(user_role, username)
        window.show()
        sys.exit(app.exec_())
    else:
        sys.exit(0)
