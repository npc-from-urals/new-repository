import sqlite3

class Database:
    def __init__(self, db_name='Krasota.db'):
        self.db_name = db_name
        self.create_tables()
        self.init_admin()
    
    def get_connection(self):
        return sqlite3.connect(self.db_name)
    
    def create_tables(self):
        with self.get_connection() as conn:
            c = conn.cursor()
            c.execute('CREATE TABLE IF NOT EXISTS Users (idUser INTEGER PRIMARY KEY AUTOINCREMENT, Login TEXT UNIQUE, Password TEXT, Role TEXT DEFAULT "guest")')
            c.execute('''CREATE TABLE IF NOT EXISTS Klienti (idKlienti INTEGER PRIMARY KEY AUTOINCREMENT, Familiy TEXT, Imy TEXT, Oychestvo TEXT, Adres TEXT, Gorod TEXT)''')
            c.execute('''CREATE TABLE IF NOT EXISTS UvilirIzdel (idUvilirIzdel INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, StranaIzgotov TEXT, ZavodIzgotov TEXT, Material TEXT, Proba INTEGER, Ves INTEGER, NalichieKamny TEXT, Cena INTEGER)''')
            c.execute('''CREATE TABLE IF NOT EXISTS Zakazi (idZakazi INTEGER PRIMARY KEY AUTOINCREMENT, UvilirIzdel_idUvilirIzdel INTEGER, Klienti_idKlienti INTEGER, DataZakaza TEXT, Kolichestvo INTEGER, Skidka INTEGER, FOREIGN KEY(Klienti_idKlienti) REFERENCES Klienti(idKlienti), FOREIGN KEY(UvilirIzdel_idUvilirIzdel) REFERENCES UvilirIzdel(idUvilirIzdel))''')
            conn.commit()
    
    def init_admin(self):
        with self.get_connection() as conn:
            c = conn.cursor()
            if not c.execute('SELECT * FROM Users WHERE Login = "admin"').fetchone():
                c.execute('INSERT INTO Users (Login, Password, Role) VALUES (?, ?, ?)', ('admin', 'admin', 'admin'))
    
    def check_user(self, login, password):
        with self.get_connection() as conn:
            r = conn.cursor().execute('SELECT Role FROM Users WHERE Login=? AND Password=?', (login, password)).fetchone()
            return r[0] if r else None
    
    def get_all_jewelry(self):
        with self.get_connection() as conn:
            return conn.cursor().execute('SELECT * FROM UvilirIzdel').fetchall()
    
    def get_jewelry_by_id(self, id):
        with self.get_connection() as conn:
            return conn.cursor().execute('SELECT * FROM UvilirIzdel WHERE idUvilirIzdel=?', (id,)).fetchone()
    
    def add_jewelry(self, *args):
        with self.get_connection() as conn:
            conn.cursor().execute('INSERT INTO UvilirIzdel (Name, StranaIzgotov, ZavodIzgotov, Material, Proba, Ves, NalichieKamny, Cena) VALUES (?,?,?,?,?,?,?,?)', args)
    
    def update_jewelry(self, id, *args):
        with self.get_connection() as conn:
            conn.cursor().execute('UPDATE UvilirIzdel SET Name=?, StranaIzgotov=?, ZavodIzgotov=?, Material=?, Proba=?, Ves=?, NalichieKamny=?, Cena=? WHERE idUvilirIzdel=?', (*args, id))
    
    def delete_jewelry(self, id):
        with self.get_connection() as conn:
            conn.cursor().execute('DELETE FROM UvilirIzdel WHERE idUvilirIzdel=?', (id,))
    
    def get_all_klienti(self):
        with self.get_connection() as conn:
            return conn.cursor().execute('SELECT * FROM Klienti').fetchall()
    
    def add_klient(self, *args):
        with self.get_connection() as conn:
            conn.cursor().execute('INSERT INTO Klienti (Familiy, Imy, Oychestvo, Adres, Gorod) VALUES (?,?,?,?,?)', args)
    
    def update_klient(self, id, *args):
        with self.get_connection() as conn:
            conn.cursor().execute('UPDATE Klienti SET Familiy=?, Imy=?, Oychestvo=?, Adres=?, Gorod=? WHERE idKlienti=?', (*args, id))
    
    def delete_klient(self, id):
        with self.get_connection() as conn:
            conn.cursor().execute('DELETE FROM Klienti WHERE idKlienti=?', (id,))
    
    def get_all_zakazi(self):
        with self.get_connection() as conn:
            return conn.cursor().execute('''SELECT z.idZakazi, z.Klienti_idKlienti, z.UvilirIzdel_idUvilirIzdel, z.DataZakaza, z.Kolichestvo, z.Skidka, k.Familiy||" "||k.Imy||" "||k.Oychestvo AS FIO, u.Name, u.Cena FROM Zakazi z JOIN Klienti k ON z.Klienti_idKlienti=k.idKlienti JOIN UvilirIzdel u ON z.UvilirIzdel_idUvilirIzdel=u.idUvilirIzdel''').fetchall()
    
    def add_zakaz(self, *args):
        with self.get_connection() as conn:
            conn.cursor().execute('INSERT INTO Zakazi (Klienti_idKlienti, UvilirIzdel_idUvilirIzdel, DataZakaza, Kolichestvo, Skidka) VALUES (?,?,?,?,?)', args)
    
    def update_zakaz(self, id, *args):
        with self.get_connection() as conn:
            conn.cursor().execute('UPDATE Zakazi SET Klienti_idKlienti=?, UvilirIzdel_idUvilirIzdel=?, DataZakaza=?, Kolichestvo=?, Skidka=? WHERE idZakazi=?', (*args, id))
    
    def delete_zakaz(self, id):
        with self.get_connection() as conn:
            conn.cursor().execute('DELETE FROM Zakazi WHERE idZakazi=?', (id,))
