from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from database import Database

class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.db = Database()
        self.user_role = 'guest'
        self.username = 'Гость'
        self.setWindowTitle('Вход')
        self.setFixedSize(300, 200)
        
        l = QVBoxLayout(self)
        l.addWidget(QLabel('Вход в систему'), 0, Qt.AlignCenter)
        
        f = QFormLayout()
        self.login = QLineEdit()
        self.passw = QLineEdit()
        self.passw.setEchoMode(QLineEdit.Password)
        f.addRow('Логин:', self.login)
        f.addRow('Пароль:', self.passw)
        l.addLayout(f)
        
        b = QHBoxLayout()
        btn_ok = QPushButton('Войти')
        btn_ok.clicked.connect(self.login_user)
        btn_guest = QPushButton('Гость')
        btn_guest.clicked.connect(self.guest_login)
        b.addWidget(btn_ok)
        b.addWidget(btn_guest)
        l.addLayout(b)
    
    def login_user(self):
        r = self.db.check_user(self.login.text(), self.passw.text())
        if r:
            self.user_role, self.username = r, self.login.text()
            self.accept()
        else:
            QMessageBox.critical(self, 'Ошибка', 'Неверные данные')
    
    def guest_login(self): self.accept()
    def get_role(self): return self.user_role
    def get_username(self): return self.username
